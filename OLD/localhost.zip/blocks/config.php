<? session_start(); ?>
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
