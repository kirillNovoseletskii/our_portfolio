<footer class="footer">
  <ul class="soc">
    <li class="soc_item"><a href="#"><i class="fab fa-github"></i></a></li>
    <li class="soc_item"><a href="#"><i class="fab fa-vk"></i></a></li>
    <li class="soc_item"><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
    <li class="soc_item"><a href="#"><i class="fab fa-twitter"></i></a></li>
    <li class="soc_item"><a href="#"><i class="fab fa-instagram"></i></a></li>
  </ul>
</footer>
<script src="https://cdn.jsdelivr.net/npm/vue"></script>
<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
<script src="../JS/first.js"></script>
<script src="../particles.js-master/particles.js"></script>
<script src="../particles.js-master/demo/js/app.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
