<? require_once "/blocks/config.php"; ?>

<!DOCTYPE html>
<head>
<?php
  $title = "Document";
  require_once "/blocks/head.php";
?>
</head>

<body>

  <div class="load">
      <div class="bg">
          <div class="cube">
            <div class="top"></div>
            <div class="right"></div>
            <div class="left"></div>
            <div class="front"></div>
            <div class="back"></div>
            <div class="bottom"></div>
          </div>
        </div>
  </div>


  <?php
    require_once '/blocks/header.php';
  ?>
  <div class="title">

    <h1>PORT<span class="folio">FOLIO</span> </h1>
  </div>
  </header>

  <?  if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      echo "Hello, ".$username;
      echo "<a href='/mycab'>Profile</a>";
      echo "<a href='/login/logout.php'>Log out</a>";
      }
      else {
        echo "<a href='/reg'>Register</a>";
        echo "<a href='/login'>Log in</a>";
      }
  ?>

  <?php
    require_once '/html/main.html';
  ?>



  <?php
    require_once '/blocks/footer.php';
  ?>


<script type="text/javascript">
$(document).ready(function () {
  $('.nav-mobile').click(function () {
    $('.mob-menu').removeClass('close_menu');
  });
  $('.close').click(function (){
    $('.mob-menu').addClass('close_menu')
  })
  $(window).scroll(function(){
    var sc  = $(this).scrollTop();
    console.log(sc.toFixed(0));
    $('.background').css('transform','translateY('+sc*1+'px)')
    $('.title').css('margin-bottom',sc*-0.1+30+'px')
  });


  $(".load").hide();



    $(".load").show('slow');
    setTimeout(function() {
      $(".load").css({
        'opacity':0,
        'transform':'scale(2)',
      });
    }, 2200);
    setTimeout(function() {
      $(".load").css({
        'display':'none'
      });
    },3000);
  });

</script>


</body>
</html>

<!--|  |-->
